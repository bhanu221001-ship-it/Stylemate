"""StyleMate API.

Run:  uvicorn app.main:app --reload --port 8000
Docs: http://localhost:8000/docs
"""
from __future__ import annotations

import json
import secrets
import time
from pathlib import Path
from typing import Any

from fastapi import FastAPI, File, HTTPException, UploadFile, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .catalogue.store import catalogue
from .config import settings
from .llm.router import llm
from .models import (AvatarRequest, FitRequest, LLMSettings, PaletteRequest,
                     SearchRequest, SizeProfile, SyncRequest, TryOnRequest)
from .services import avatar as avatar_svc
from .services import fit as fit_svc
from .services import garment as garment_svc
from .services import look as look_svc
from .services import palette as palette_svc
from .services import search as search_svc

app = FastAPI(title="StyleMate API", version="1.0.0")
app.add_middleware(
    CORSMiddleware, allow_origins=list(settings.cors_origins) or ["*"],
    allow_credentials=False, allow_methods=["*"], allow_headers=["*"])

MAX_UPLOAD = 12 * 1024 * 1024          # 12 MB
ALLOWED = {"image/jpeg", "image/png", "image/webp"}
STATIC = Path(__file__).parent / "static"
ASSETS = settings.cache_dir.parent / "garment_assets"
ASSETS.mkdir(parents=True, exist_ok=True)


# --------------------------------------------------------------------- misc
@app.get("/api/health")
def health() -> dict:
    h = llm.health()
    return {
        "ok": True,
        "catalogue": {"products": len(catalogue),
                      "lastSync": catalogue.get_meta("lastSync")},
        "llm": h,
        "features": {
            "search": {"ready": True,
                       "aiUnderstanding": h.get("textModelReady", False),
                       "note": "Rule parsing always works; the model adds "
                               "sentence understanding."},
            "shopALook": {"ready": True,
                          "visionModel": h.get("visionModelReady", False),
                          "note": "Zone analysis always works; a vision model "
                                  "adds garment recognition."},
            "fittingRoom": {"ready": True, "clothSimulation": False,
                            "supplierMeshes": any(ASSETS.glob("*.gl*")),
                            "note": "Avatar and fit maths are local. Garment "
                                    "shells are measurement-derived, not cloth "
                                    "simulation."},
        },
    }


@app.get("/api/settings/llm")
def llm_settings() -> dict:
    """Current provider state. Never returns the API key itself."""
    return llm.health_all()


@app.post("/api/settings/llm")
def set_llm_settings(cfg: LLMSettings) -> dict:
    return llm.configure(**cfg.model_dump(exclude_none=True))


@app.get("/api/settings/gemini/models")
def gemini_models() -> dict:
    """Live model list for the key that is set, or the known-good fallback."""
    return llm.gemini.list_models()


@app.get("/api/catalogue/stats")
def cat_stats() -> dict:
    return {"count": len(catalogue), "facets": catalogue.facets(),
            "lastSync": catalogue.get_meta("lastSync")}


@app.post("/api/catalogue/sync")
def cat_sync(req: SyncRequest) -> dict:
    if not req.products:
        raise HTTPException(400, "No products supplied.")
    n = catalogue.upsert(req.products)
    catalogue.set_meta("lastSync", time.strftime("%Y-%m-%d %H:%M:%S"))
    return {"stored": n, "total": len(catalogue)}


# ------------------------------------------------------------------- search
@app.post("/api/search")
def api_search(req: SearchRequest) -> dict:
    if not req.q.strip():
        raise HTTPException(400, "Empty query.")
    return search_svc.search(req.q, limit=req.limit, use_model=req.useModel,
                             profile=req.profile)


# ------------------------------------------------------------------ palette
@app.post("/api/palette")
def api_palette(req: PaletteRequest) -> dict:
    """Seasonal palette for a skin reading, plus products in those colours."""
    return palette_svc.recommend(
        req.undertone, req.depth, season_key=req.season,
        audience=req.audience, per_row=max(1, min(req.perRow, 24)),
        budget_max=req.budgetMax)


@app.get("/api/palette/seasons")
def api_seasons() -> dict:
    return {"seasons": [s.dict() for s in palette_svc.SEASONS.values()]}


# -------------------------------------------------------------- shop a look
def _read_upload(f: UploadFile) -> bytes:
    if f.content_type not in ALLOWED:
        raise HTTPException(415, f"Only JPEG, PNG or WebP. Got {f.content_type}.")
    data = f.file.read(MAX_UPLOAD + 1)
    if len(data) > MAX_UPLOAD:
        raise HTTPException(413, "Image larger than 12 MB.")
    if not data:
        raise HTTPException(400, "Empty file.")
    return data


@app.post("/api/look")
def api_look(photo: UploadFile = File(...), audience: str = Form(""),
             perItem: int = Form(6), useVision: int = Form(1)) -> dict:
    data = _read_upload(photo)
    return look_svc.analyse(data, audience=(audience or None),
                            per_item=perItem, use_vision=bool(useVision))


# ---------------------------------------------------------------------- fit
def _product_for(sku: str, supplied: dict | None) -> dict:
    p = catalogue.get(sku)
    if p:
        try:
            raw = json.loads(p.get("raw") or "{}")
            return {**raw, **{k: v for k, v in p.items() if v}}
        except json.JSONDecodeError:
            return p
    if supplied:
        return supplied
    raise HTTPException(404, f"Unknown SKU {sku}. Sync the catalogue first.")


@app.post("/api/fit")
def api_fit(req: FitRequest) -> dict:
    product = _product_for(req.sku, req.product)
    body = req.profile.model_dump()
    unit = body.pop("unit", "cm")
    size = req.size or fit_svc.best_size(product, body, unit) or "M"
    report = fit_svc.evaluate(product, size, body, unit)
    return report.dict()


@app.post("/api/fit/batch")
def api_fit_batch(req: TryOnRequest) -> dict:
    body = req.profile.model_dump()
    unit = body.pop("unit", "cm")
    out = []
    for it in req.items:
        sku = str(it.get("sku") or it.get("id") or "")
        if not sku:
            continue
        product = _product_for(sku, it.get("product"))
        size = it.get("size") or fit_svc.best_size(product, body, unit) or "M"
        out.append(fit_svc.evaluate(product, size, body, unit).dict())
    return {"reports": out}


# ------------------------------------------------------------------- avatar
PHOTOS: dict[str, dict] = {}        # photoId -> {bytes, evidence}


@app.post("/api/avatar/photo")
def api_avatar_photo(photo: UploadFile = File(...)) -> dict:
    """Analyse a body photo. The image is held in memory for this process
    only, is never written to a public path, and is dropped by /api/avatar/forget."""
    data = _read_upload(photo)
    ev = avatar_svc.analyse_photo(data)
    pid = secrets.token_urlsafe(12)
    PHOTOS[pid] = {"bytes": data, "evidence": ev}
    return {"photoId": pid, "evidence": ev.dict(),
            "note": "The photo stays in server memory and is not served from "
                    "any URL. Use Forget my photo to remove it."}


@app.post("/api/avatar/forget")
def api_avatar_forget(photoId: str = Form(...)) -> dict:
    existed = PHOTOS.pop(photoId, None) is not None
    return {"removed": existed}


@app.post("/api/avatar")
def api_avatar(req: AvatarRequest) -> dict:
    prof = req.profile.model_dump()
    m, supplied, defaulted = avatar_svc.resolve_measurements(prof)
    ev = None
    notes: list[str] = []
    if req.photoId:
        rec = PHOTOS.get(req.photoId)
        if not rec:
            notes.append("That photo is no longer held on the server; "
                         "the avatar was built from measurements alone.")
        else:
            ev = rec["evidence"]
            m, ev_notes = avatar_svc.apply_evidence(m, ev)
            notes.extend(ev_notes)
            notes.extend(ev.notes)
    mesh = avatar_svc.build_mesh(m, evidence=ev)
    clean = {k: v for k, v in m.items() if not k.startswith("_")}
    return {
        "mesh": mesh,
        "measurementsCm": clean,
        "supplied": supplied,
        "defaulted": defaulted,
        "skinRgb": list(ev.skin_rgb) if (ev and ev.skin_rgb) else None,
        "photoEvidence": ev.dict() if ev else None,
        "notes": notes,
        "method": "parametric-anthropometric",
        "disclosure": (
            "This is a parametric mesh built from your measurements, not a 3D "
            "scan. A single photograph carries no depth, so it is used only to "
            "check proportions and sample skin tone - never to infer your "
            "body shape. Measurements you have not entered use a population "
            "default and are listed under 'defaulted'."),
    }


@app.post("/api/fittingroom")
def api_fittingroom(req: TryOnRequest) -> dict:
    """Everything the 3D fitting room needs in one call."""
    prof = req.profile.model_dump()
    unit = prof.get("unit", "cm")
    m, supplied, defaulted = avatar_svc.resolve_measurements(prof)
    ev = None
    notes: list[str] = []
    if req.photoId and req.photoId in PHOTOS:
        ev = PHOTOS[req.photoId]["evidence"]
        m, ev_notes = avatar_svc.apply_evidence(m, ev)
        notes.extend(ev_notes + ev.notes)

    mesh = avatar_svc.build_mesh(m, evidence=ev)
    body = {k: v for k, v in prof.items() if k != "unit"}
    height_cm = m["height"]

    garments, reports = [], []
    for it in req.items:
        sku = str(it.get("sku") or it.get("id") or "")
        if not sku:
            continue
        product = _product_for(sku, it.get("product"))
        size = it.get("size") or fit_svc.best_size(product, body, unit) or "M"
        report = fit_svc.evaluate(product, size, body, unit)
        reports.append(report.dict())
        shell = garment_svc.build_shell(product, size, m, height_cm)
        shell["name"] = product.get("name")
        shell["image"] = product.get("image")
        shell["colour"] = product.get("colour")
        shell["overall"] = report.overall
        garments.append(shell)

    return {
        "mesh": mesh,
        "measurementsCm": {k: v for k, v in m.items() if not k.startswith("_")},
        "supplied": supplied, "defaulted": defaulted,
        "skinRgb": list(ev.skin_rgb) if (ev and ev.skin_rgb) else None,
        "garments": garments,
        "fitReports": reports,
        "notes": notes,
        "disclosure": (
            "The body is a parametric mesh from your measurements. Garment "
            "shapes are lofted from each item's size chart - they show how "
            "much room the garment has and where it ends, not the product's "
            "real cut. No cloth simulation is running."),
    }


# ------------------------------------------------------------------- assets
@app.get("/assets/garments/{name}")
def garment_asset(name: str):
    p = (ASSETS / name).resolve()
    if not str(p).startswith(str(ASSETS.resolve())) or not p.exists():
        raise HTTPException(404, "No such asset.")
    return FileResponse(p)


if STATIC.exists():
    app.mount("/", StaticFiles(directory=STATIC, html=True), name="static")
