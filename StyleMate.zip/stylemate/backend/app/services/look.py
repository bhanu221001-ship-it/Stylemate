"""Shop a look: recognise what a person is wearing, then find it here.

Two detection paths, picked at runtime:

  VISION MODEL (preferred) - a multimodal model (default qwen2.5vl:7b via
      Ollama) is asked to list every wearable item with its slot, colour,
      pattern and material. This is what actually recognises "a brown leather
      strap watch" as opposed to "a brown region".

  ZONE ANALYSIS (fallback, always available) - OpenCV segments the subject and
      splits the figure into anatomical bands (head, torso, hips, legs, feet).
      The dominant non-skin colour of each band becomes a garment guess for the
      slot that band belongs to. This genuinely reads colour and placement off
      the photo, but it cannot tell a shirt from a sweatshirt, and the payload
      says so.

Either way the MATCHING is the same deterministic retrieval used by search:
a detected item becomes a slot + colour constraint, and the catalogue is ranked
against it. Nothing is matched by the model's say-so.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict

import numpy as np

from ..catalogue.compat import SLOT_CATEGORIES, goes_with_colour, slot_of
from ..catalogue.store import catalogue
from ..config import settings
from ..llm.router import LLMUnavailable, llm

VISION_SYSTEM = """You identify clothing and accessories in a photograph of a \
person. You are a catalogue tagger, not a stylist.

Return ONLY JSON:
{"items":[{
  "slot": "top"|"bottom"|"dress"|"outerwear"|"footwear"|"jewellery"|"bag"|
          "watch"|"eyewear"|"belt"|"headwear",
  "label": short description, e.g. "light blue denim jacket",
  "article_type": the garment noun, e.g. "Jacket", "Jeans", "Sneakers",
  "colour": the single dominant colour word,
  "secondary_colour": string or null,
  "pattern": "solid"|"striped"|"checked"|"printed"|"floral"|"textured"|null,
  "material": best guess or null,
  "worn_by": "menswear"|"womenswear"|"unisex",
  "confidence": 0.0-1.0
}]}

Rules:
- "worn_by" describes the GARMENT, not the person: a kurta cut for men is
  "menswear", a saree is "womenswear", a plain tee is "unisex". Judge it from
  the cut, neckline and styling. Use "unisex" when it genuinely could be
  either. This decides which part of the catalogue is searched, so a men's
  outfit must not come back as women's dresses.
- One entry per visible item. Do not list the person, skin, hair or background.
- If an item is partly out of frame or ambiguous, still list it with a low
  confidence rather than guessing a specific brand.
- Never name a brand. You cannot read brands reliably from a photo.
- If you see no person or no clothing, return {"items":[]}.
"""

# Which band of the figure each slot normally occupies, as fractions of the
# subject's height measured from the top of the head.
BANDS = {
    "headwear": (0.00, 0.12),
    "top":      (0.20, 0.48),
    "outerwear": (0.20, 0.52),
    "bottom":   (0.50, 0.88),
    "footwear": (0.90, 1.00),
}


@dataclass
class DetectedItem:
    slot: str
    label: str
    article_type: str | None = None
    colour: str | None = None
    secondary_colour: str | None = None
    pattern: str | None = None
    material: str | None = None
    worn_by: str | None = None       # menswear | womenswear | unisex
    confidence: float = 0.0
    source: str = "vision"
    rgb: list | None = None

    def dict(self) -> dict:
        return asdict(self)


# --- catalogue colour vocabulary -----------------------------------------
BASE_RGB = {
    "black": (26, 26, 26), "white": (245, 245, 245), "off white": (238, 234, 222),
    "grey": (138, 138, 138), "charcoal": (74, 78, 82), "navy blue": (28, 42, 86),
    "blue": (48, 96, 180), "teal": (36, 122, 122), "green": (56, 122, 64),
    "olive": (110, 112, 60), "red": (176, 42, 42), "maroon": (108, 30, 42),
    "pink": (222, 136, 160), "purple": (108, 70, 150), "lavender": (190, 176, 220),
    "yellow": (226, 196, 72), "mustard": (196, 154, 48), "orange": (214, 118, 48),
    "rust": (162, 80, 48), "brown": (112, 78, 56), "coffee brown": (82, 58, 44),
    "beige": (214, 196, 166), "cream": (238, 226, 198), "tan": (196, 158, 110),
    "khaki": (178, 162, 118), "gold": (198, 162, 72), "silver": (190, 194, 198),
    "peach": (240, 186, 158), "magenta": (186, 52, 130), "turquoise blue": (62, 186, 194),
}


def nearest_colour(rgb) -> str:
    r, g, b = [float(x) for x in rgb]
    best, bd = "black", 1e9
    for name, (nr, ng, nb) in BASE_RGB.items():
        d = (r - nr) ** 2 * 0.30 + (g - ng) ** 2 * 0.59 + (b - nb) ** 2 * 0.11
        if d < bd:
            best, bd = name, d
    return best


def _is_skin(r, g, b) -> bool:
    y = 0.299 * r + 0.587 * g + 0.114 * b
    cb = 128 - 0.168736 * r - 0.331264 * g + 0.5 * b
    cr = 128 + 0.5 * r - 0.418688 * g - 0.081312 * b
    return 55 < y and 77 <= cb <= 132 and 132 <= cr <= 178 and r > g >= b - 12


def _skin_mask(img):
    import cv2
    b, g, r = img[:, :, 0].astype(int), img[:, :, 1].astype(int), img[:, :, 2].astype(int)
    y = 0.299 * r + 0.587 * g + 0.114 * b
    cb = 128 - 0.168736 * r - 0.331264 * g + 0.5 * b
    cr = 128 + 0.5 * r - 0.418688 * g - 0.081312 * b
    mx = np.maximum(np.maximum(r, g), b)
    mn = np.minimum(np.minimum(r, g), b)
    sat = np.where(mx > 0, (mx - mn) / np.maximum(mx, 1), 0)
    # Skin is chromatic and not blown out. Without these two bounds a white or
    # cream shirt passes every YCbCr test and gets mistaken for a face, which
    # then anchors the whole body in the wrong place.
    m = ((y > 55) & (cb >= 77) & (cb <= 132) & (cr >= 132) & (cr <= 178)
         & (r > g) & (g >= b - 14)
         & (sat > 0.15) & (mx < 245)).astype(np.uint8)
    return cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))


def _find_face(img):
    """Largest skin region in the upper half, as (cx, cy, w, h).

    This build of OpenCV has no cascade or HOG detector, so the face is found
    by skin colour and connected components. It is the anchor for everything
    else: without a face we do not know where the person is, and guessing
    produces the nonsense this replaced - "turquoise headwear" read off a
    night sky.
    """
    import cv2
    h, w = img.shape[:2]
    mask = _skin_mask(img)
    mask[int(h * 0.62):, :] = 0                 # faces are not at the ankles
    n, labels, stats, cents = cv2.connectedComponentsWithStats(mask, 8)
    best = None
    for i in range(1, n):
        x, y, bw, bh, area = stats[i]
        if area < (h * w) * 0.0012:
            continue
        if area > (h * w) * 0.10:               # too big to be a face
            continue
        ratio = bh / max(1, bw)
        if not (0.6 <= ratio <= 2.4):           # a face is roughly upright-oval
            continue
        # Prefer blobs that are high in the frame and near the centre: the face
        # sits above the hands and any other skin the photo shows.
        height_bonus = 1.0 - (cents[i][1] / h)
        centre_bonus = 1.0 - abs(cents[i][0] / w - 0.5)
        score = area * (0.45 + height_bonus) * centre_bonus
        if best is None or score > best[0]:
            best = (score, int(cents[i][0]), int(cents[i][1]), int(bw), int(bh))
    if not best:
        return None
    return best[1], best[2], best[3], best[4]


def detect_zones(image_bytes: bytes) -> list[DetectedItem]:
    """Fallback detector: anchor on the face, then read each band's colour.

    Always available - no model, no download. It knows WHERE an item sits, not
    what kind of garment it is, and it refuses to report anything when it
    cannot find a person.
    """
    import cv2
    arr = np.frombuffer(image_bytes, np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        return []
    h, w = img.shape[:2]
    scale = 640.0 / max(h, w)
    if scale < 1.0:
        img = cv2.resize(img, (int(w * scale), int(h * scale)))
        h, w = img.shape[:2]

    face = _find_face(img)
    if not face:
        return []
    fx, fy, fw, fh = face
    head = max(fh, fw * 1.25)

    # Adult proportions: about 7.5 head-heights tall, shoulders ~1.6 heads wide.
    crown = max(0, fy - int(head * 0.55))
    body_px = head * 7.5
    # Shoulders are about two head-widths across, so sample the torso core
    # rather than a box wide enough to be mostly background.
    half_w = int(head * 0.95)
    x0, x1 = max(0, fx - half_w), min(w, fx + half_w)
    if x1 - x0 < 12:
        return []

    bg = np.median(np.concatenate([
        img[0:10, 0:10].reshape(-1, 3), img[0:10, -10:].reshape(-1, 3),
        img[-10:, 0:10].reshape(-1, 3), img[-10:, -10:].reshape(-1, 3)]), axis=0)

    skin = _skin_mask(img)
    bands = [
        ("headwear", -0.60, -0.15),
        ("top",       0.95,  2.90),
        ("bottom",    3.10,  5.90),
        ("footwear",  6.60,  7.40),
    ]
    out: list[DetectedItem] = []
    for slot, a, b in bands:
        y0 = crown + int(head * a)
        y1 = crown + int(head * b)
        y0, y1 = max(0, y0), min(h, y1)
        if y1 - y0 < 8:
            continue
        patch = img[y0:y1, x0:x1].reshape(-1, 3)
        spatch = skin[y0:y1, x0:x1].reshape(-1)
        # Drop skin AND anything that matches the background, before measuring
        # dominance - otherwise a busy backdrop decides the answer.
        notbg = np.linalg.norm(patch.astype(float) - bg, axis=1) > 46
        keep = (spatch == 0) & notbg
        if keep.sum() < 60 or keep.sum() < 0.12 * len(patch):
            continue
        px = patch[keep]
        data = np.float32(px)
        k = min(3, max(1, len(data) // 80))
        crit = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 14, 1.0)
        _, labels, centres = cv2.kmeans(data, k, None, crit, 3, cv2.KMEANS_PP_CENTERS)
        counts = np.bincount(labels.flatten(), minlength=k)
        idx = int(np.argmax(counts))
        c = centres[idx]
        share = float(counts[idx] / counts.sum())
        # A band that is mostly background, or has no dominant colour at all,
        # is not a garment.
        if float(np.linalg.norm(c - bg)) < 46:
            continue
        if share < 0.40:
            continue
        rgb = [int(c[2]), int(c[1]), int(c[0])]
        name = nearest_colour(rgb)
        out.append(DetectedItem(
            slot=slot, label=f"{name} item on the {slot}", colour=name,
            confidence=round(min(0.6, 0.2 + share * 0.45), 2),
            source="zones", rgb=rgb))
    return out


def detect_vision(image_bytes: bytes) -> tuple[list[DetectedItem], str]:
    """Ask the multimodal model what the person is wearing."""
    data, reply = llm.chat_json(
        VISION_SYSTEM,
        "List every clothing item and accessory this person is wearing.",
        images=[image_bytes], model=settings.vision_model, temperature=0.1)
    items = []
    raw = data.get("items") if isinstance(data, dict) else data
    for it in (raw or []):
        if not isinstance(it, dict):
            continue
        slot = str(it.get("slot") or "").lower().strip()
        if slot not in SLOT_CATEGORIES:
            slot = slot_of(str(it.get("article_type") or ""),
                           str(it.get("label") or "")) or ""
        if not slot:
            continue
        items.append(DetectedItem(
            slot=slot, label=str(it.get("label") or slot),
            article_type=(str(it["article_type"]) if it.get("article_type") else None),
            colour=(str(it["colour"]).lower() if it.get("colour") else None),
            secondary_colour=(str(it["secondary_colour"]).lower()
                              if it.get("secondary_colour") else None),
            pattern=(str(it["pattern"]) if it.get("pattern") else None),
            material=(str(it["material"]) if it.get("material") else None),
            worn_by=(str(it["worn_by"]).lower() if it.get("worn_by") else None),
            confidence=float(it.get("confidence") or 0.5),
            source="vision"))
    return items, (f"{reply.model} in {reply.seconds:.1f}s")


# Catalogue audience values for each garment-gender the model may report.
_WORN_BY_AUDIENCE = {
    "menswear": "men", "mens": "men", "men": "men", "male": "men",
    "womenswear": "women", "womens": "women", "women": "women",
    "female": "women",
    "unisex": None, "boys": "men", "girls": "women",
}


def match_item(item: DetectedItem, *, limit: int = 6,
               audience: str | None = None) -> list[dict]:
    """Rank catalogue products against one detected item. Deterministic.

    `audience` is the shopper's own default. A garment the model identified as
    menswear or womenswear overrides it, because that is read from the actual
    item rather than assumed.
    """
    if item.worn_by:
        mapped = _WORN_BY_AUDIENCE.get(item.worn_by, None)
        if mapped:
            audience = mapped
    cats = SLOT_CATEGORIES.get(item.slot, [])
    rows = catalogue.rows
    want_colour = (item.colour or "").lower()
    query = " ".join(x for x in (item.article_type, item.pattern,
                                 item.material, item.label) if x)
    bm = catalogue.bm25(query) if query else {}
    bm_max = max(bm.values()) if bm else 1.0

    scored = []
    for i, r in enumerate(rows):
        if item.slot and r["slot"] and r["slot"] != item.slot:
            continue
        if cats and r["cat"] not in cats:
            continue
        if audience and r["audience"] not in (audience, "unisex", ""):
            continue
        s, why = 0.0, []
        if audience and r["audience"] == audience:
            s += 0.6
        lex = (bm.get(i, 0.0) / bm_max) if bm_max else 0.0
        s += lex * 2.4
        if lex > 0.4 and item.article_type:
            why.append(f"same kind of item ({item.article_type.lower()})")
        rc = (r["colour"] or "").lower()
        if want_colour and rc:
            if rc == want_colour:
                s += 3.0
                why.append(f"same colour ({r['colour']})")
            else:
                aff = goes_with_colour(want_colour, rc)
                s += aff * 1.1
                if aff >= 0.8:
                    why.append(f"{r['colour']} reads close to {want_colour}")
        if item.rgb and rc in BASE_RGB:
            d = sum((a - b) ** 2 for a, b in zip(item.rgb, BASE_RGB[rc])) ** 0.5
            s += max(0.0, 1.6 - d / 120.0)
        if not why:
            why.append(f"a {r['slot'] or r['cat']} in the same part of the outfit")
        scored.append((s, i, why))

    scored.sort(key=lambda t: (-t[0], t[1]))
    out = []
    for s, i, why in scored[:limit]:
        r = dict(rows[i])
        raw = r.pop("raw", None)
        try:
            r.update({k: v for k, v in (json.loads(raw) or {}).items()
                      if k not in r or not r[k]})
        except Exception:                      # noqa: BLE001
            pass
        r["score"] = round(s, 3)
        r["why"] = why[:2]
        out.append(r)
    return out


def analyse(image_bytes: bytes, *, audience: str | None = None,
            per_item: int = 6, use_vision: bool = True) -> dict:
    """Full pipeline: detect, then match each detected item."""
    detector, note = "zones", ""
    items: list[DetectedItem] = []
    if use_vision:
        try:
            items, note = detect_vision(image_bytes)
            detector = "vision"
        except (LLMUnavailable, ValueError) as e:
            note = (f"Vision model unavailable ({e}). Fell back to colour-and-"
                    f"placement analysis, which reads colours off the photo but "
                    f"cannot name the garment type.")
        except Exception as e:                  # noqa: BLE001
            note = (f"Vision model failed ({type(e).__name__}: {e}). Fell back "
                    f"to colour-and-placement analysis.")
    if not items:
        items = detect_zones(image_bytes)
        if detector == "vision" and not note:
            note = "The vision model returned nothing; used zone analysis."
        detector = "zones"

    results = []
    for it in items:
        results.append({
            "detected": it.dict(),
            "matches": match_item(it, limit=per_item, audience=audience),
        })
    return {
        "detector": detector,
        "note": note or ("Items recognised by the vision model; matches ranked "
                         "against the catalogue by colour, type and placement."),
        "items": results,
        "limits": (
            "Matches are StyleMate products that resemble what was detected. "
            "They are not the same product, and no brand is identified from a "
            "photograph."
            if detector == "vision" else
            "Without a vision model this reads the dominant colour of each part "
            "of the figure. It knows WHERE an item sits, not what kind of "
            "garment it is - pull a vision model for proper recognition."),
    }
